NORTH EAST BYTE NEWS — FREE STATIC WEBSITE

এই ফোল্ডারের index.html খুললেই ওয়েবসাইট দেখা যাবে।

ফ্রি-তে অনলাইনে প্রকাশ করার সহজ উপায়:
1. GitHub-এ একটি account খুলুন।
2. New repository তৈরি করুন।
3. এই ফোল্ডারের সব ফাইল upload করুন।
4. Settings → Pages → Deploy from branch → main / root নির্বাচন করুন।
5. কিছুক্ষণ পর GitHub আপনাকে একটি free website address দেবে।

বদলানোর জায়গা:
- index.html: খবর, Facebook/YouTube link, About, Contact
- style.css: রং/ডিজাইন
- northeast-byte-logo.png: লোগো

বর্তমান যোগাযোগ:
Email: northeastbyte@gmail.com
Messenger/Page name: NorthEast Byte News
Address shown in supplied screenshot: Northeast, Agartala, India, 799003

নোট: Facebook/YouTube-এর সঠিক page URL দেওয়া হয়নি, তাই ইচ্ছাকৃতভাবে ভুয়া URL বসানো হয়নি।
